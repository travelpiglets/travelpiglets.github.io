---
name: Feature request
about: Suggest a new feature for Thumbsup.
labels: enhancement
---

## Feature name

<!--
Please describe the new feature or behaviour you'd like to see.
If possible, give concrete use cases.

If this is a high-level idea or a question like "how do I..."
then a Discussion might be a better choice.
-->
