exports.index = require('./step-index').run
exports.process = require('./step-process').run
exports.cleanup = require('./step-cleanup').run
exports.zipAlbums = require('./step-album-zip').run
